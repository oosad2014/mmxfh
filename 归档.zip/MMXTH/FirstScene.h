//
//  FirstScene.h
//
//  Created by : mac
//  Project    : MMXTH
//  Date       : 16/9/12
//
//  Copyright (c) 2016年 xc.
//  All rights reserved.
//
// -----------------------------------------------------------------

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "cocos2d-ui.h"

// -----------------------------------------------------------------

@interface FirstScene : CCScene

// -----------------------------------------------------------------
// properties

// -----------------------------------------------------------------
// methods

+ (FirstScene *)scene;
- (id)init;
-(void)initScene;

// -----------------------------------------------------------------

@end




