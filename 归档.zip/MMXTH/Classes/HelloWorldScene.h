//
//  HelloWorldScene.h
//
//  Created by : xc
//  Project    : MMXTH
//  Date       : 16/9/9
//
//  Copyright (c) 2016年 xc.
//  All rights reserved.
//
// -----------------------------------------------------------------

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "cocos2d-ui.h"

// -----------------------------------------------------------------------

@interface HelloWorldScene : CCScene

// -----------------------------------------------------------------------

- (instancetype)init;

// -----------------------------------------------------------------------

@end


































