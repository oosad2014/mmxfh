 //
//  main.m
//  cocos2d-template
//
//  Created by Lars Birkemose on 24/06/15.
//  Copyright cocos2d.org 2015. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
