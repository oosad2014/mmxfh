//
//  TestChinaMapScene.h
//  MMXTH
//
//  Created by 修海锟 on 2017/3/26.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "cocos2d-ui.h"

@interface TestChinaMapScene : CCScene

+(TestChinaMapScene *)scene;
- (id)init;

@end
